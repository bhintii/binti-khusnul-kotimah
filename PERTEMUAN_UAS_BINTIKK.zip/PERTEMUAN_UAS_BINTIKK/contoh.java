/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PERTEMUAN_UAS_BINTIKK;

/**
 *
 * @author LENOVO
 */
public class contoh {
    public static void main(String[]args){
        System.out.println("oke");
    }
    
}
